package assignment1;

public class Figure {
    final int height;

    Figure(int height) {
        this.height = height;
    }
}
