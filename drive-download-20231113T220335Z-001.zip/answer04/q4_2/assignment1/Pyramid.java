package assignment1;

public class Pyramid extends Figure {
    Pyramid(int height) {
        super(height);
    }
}
