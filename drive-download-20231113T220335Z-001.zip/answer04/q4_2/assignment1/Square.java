package assignment1;

public class Square extends Rectangle{
    Square(int height) {
        super(height, height);
    }
}
