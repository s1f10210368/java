package assignment1.figures;

import assignment1.base.Figure;

public class Square extends Rectangle{
    public Square(int height) {
        super(height, height);
    }
}
