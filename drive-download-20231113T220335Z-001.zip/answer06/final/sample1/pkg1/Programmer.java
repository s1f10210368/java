package sample1.pkg1;

public interface Programmer {
    boolean canWritePython();
    boolean canWriteC();
    boolean canWriteJava();
}
