package assignment1;

public class Rectangle extends Figure{
    final int width;

    Rectangle(int height, int width) {
        super(height);
        this.width = width;
    }
}
