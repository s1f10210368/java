public class Echo {
    public static void main(String[] args) {
        System.out.println(args[0]);
    }
}
